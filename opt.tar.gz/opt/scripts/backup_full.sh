function mostrar_ayuda() {
    echo ""
    echo "Uso:"
    echo "    backup_full.sh <origen> <destino>"
    echo ""
    echo "Argumentos"
    echo "    origen  Ruta de la carpeta a ser copiada"
    echo "    destino Ruta hacia donde copiar la carpeta de origen"
    echo "    -help   Muestra esta ayuda"

    exit
}

# Mostrar la ayuda cuando se utiliza el argumento correcto
if [ "$1" = "-help" ]; then
    echo "Script backup para guardar los datos del servidor"
    mostrar_ayuda
fi

# Mostrar mensaje de error y la ayuda cuando la cantidad de argumentos no es valida
if [ $# -lt 2 ]; then
    echo "Error: Debe proporcionar la cantidad correcta de argumentos"
    mostrar_ayuda
fi

# Argumentos
ORIGEN=$1
DESTINO=$2

# Verificamos que las carpetas existan
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: Carpeta origen '$ORIGEN' no exste"

    exit
fi
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: Carpeta destino '$DESTINO' no exste"

    exit
fi

# Obtener la fecha de hoy en formato YYYYMMDD
FECHA=`date +%Y%m%d`
# Generar parte del nombre del archivo
CARPETA_ORIGEN=${echo "$ORIGEN" | awk -F'/' '{ print $NF"_bkp_" }'}
# Generar en nombre del archivo destino
ARCHVIVO_DESTINO="$CARPETA_ORIGEN$FECHA.tar.gz"

echo "Haciendo backup de $ORIGEN en $DESTINO"

tar -czvf "$DESTINO/$ARCHVIVO_DESTINO" $ORIGEN > /dev/null

echo "Backup completado. Guardado en $DESTINO/$ARCHVIVO_DESTINO"