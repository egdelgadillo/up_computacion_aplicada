function mostrar_ayuda() {
    echo ""
    echo "Uso:"
    echo "    backup_full.sh <origen> <destino>"
    echo ""
    echo "Argumentos"
    echo "    origen  Ruta de la carpeta a ser copiada"
    echo "    destino Ruta hacia donde copiar la carpeta de origen"
    echo "    -help   Muestra esta ayuda"

    exit
}

# Mostrar la ayuda cuando se utiliza el argumento correcto
if [ "$1" = "-help" ]; then
    echo "Script backup para guardar los datos del servidor"
    mostrar_ayuda
fi

# Mostrar mensaje de error y la ayuda cuando la cantidad de argumentos no es valida
if [ $# -lt 2 ]; then
    echo "Error: Debe proporcionar la cantidad correcta de argumentos"
    mostrar_ayuda
fi

# Argumentos
CARPETA_ORIGEN=$1
CARPETA_DESTINO=$2

# Verificamos que las carpetas existan
if [[ ! -d "$CARPETA_ORIGEN" ]]; then
    echo "Error: Carpeta origen '$CARPETA_ORIGEN' no exste"

    exit
fi
if [[ ! -d "$CARPETA_DESTINO" ]]; then
    echo "Error: Carpeta destino '$CARPETA_DESTINO' no exste"

    exit
fi

# Obtener la fecha de hoy en formato YYYYMMDD
FECHA=`date +%Y%m%d`
 # Elimina un '/' al final si existe
ORIGEN="${CARPETA_ORIGEN%/}"       
# Generar el nombre del archivo destino                                                              
ARCHVIVO_DESTINO="${ORIGEN##*/}_bkp_$FECHA.tar.gz"

echo "Haciendo backup de $CARPETA_ORIGEN en $CARPETA_DESTINO"

tar -czvf "$CARPETA_DESTINO$ARCHVIVO_DESTINO" $CARPETA_ORIGEN

echo "Backup completado. Guardado en $CARPETA_DESTINO$ARCHVIVO_DESTINO"