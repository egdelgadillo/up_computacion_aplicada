rm -rf /*.tar*

tar -czvf /entrega/root.tar.gz /root
tar -czvf /entrega/etc.tar.gz /etc
tar -czvf /entrega/opt.tar.gz /opt
tar -czvf /entrega/www_dir.tar.gz /www_dir
tar -czvf /entrega/backup_dir.tar.gz /backup_dir
tar -czvf - /var | split --bytes=20971520 - /entrega/var.tar.gz
